VETER NATIVE RUNTIME 1.0
========================

This is a Windows desktop preview prototype. It reads website.vtr and draws
supported page elements in its own native Windows window using Win32 controls.
It does NOT generate HTML, CSS, or JavaScript files and does NOT open Chrome.

QUICK START
1. Install MSYS2 and its UCRT64 GCC compiler.
2. Extract this ZIP.
3. Double-click BUILD-AND-RUN-VETER.bat.
4. The script builds veter-native.exe and opens website.vtr in a native window.

RUN ANOTHER .VTR FILE
Open Command Prompt in this folder and run:
  veter-native.exe "C:\path\to\your\website.vtr"

SUPPORTED .VTR COMMANDS
  make a website called "..."
  set page title "..."
  set background color light blue
  set text color dark blue
  set font "Arial"
  center content
  show a title "..."
  show a subtitle "..."
  show text "..."
  add a text box called "..."
  add a password box called "..."
  add a checkbox "..."
  add a button "..."
  when button "..." show alert "..."
  add a link "Label" "https://example.com"

CURRENT LIMITATIONS
- This is an early native UI prototype, not a full web browser.
- Text boxes and checkboxes are currently visual placeholders.
- Buttons show configured alert messages.
- Links open the system browser.
- Images, complex layouts, networking, navigation, and responsive page
  behavior are not implemented.
- The runtime and builder are separate tools at this stage.

Your source file remains website.vtr. No .html output is created by this runtime.
