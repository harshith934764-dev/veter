@echo off
setlocal
cd /d "%~dp0"
echo ======================================
echo       VETER NATIVE UI RUNTIME
echo ======================================
echo.
where g++ >nul 2>nul
if errorlevel 1 (
  echo ERROR: g++ was not found in PATH.
  echo Open MSYS2 UCRT64 and add its bin folder to PATH, or run this from that terminal.
  pause
  exit /b 1
)
echo Building Veter Native Preview...
g++ -std=c++17 -O0 -g -Wall -Wextra Veter_Native_Engine.cpp -o veter-native-preview.exe -luser32 -lgdi32 -lshell32
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Please send a screenshot of this window.
  pause
  exit /b 1
)
echo.
echo BUILD SUCCESSFUL.
echo Starting website.vtr...
echo.
veter-native-preview.exe website.vtr
echo.
echo Preview process ended with exit code %errorlevel%.
pause
