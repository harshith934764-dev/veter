@echo off
setlocal
cd /d "%~dp0"
echo ==========================================
echo          VETER NATIVE RUNTIME 1.0
echo ==========================================
where g++ >nul 2>nul
if errorlevel 1 (
  echo ERROR: g++ was not found.
  echo Install MSYS2 UCRT64 GCC, then run this file again.
  pause
  exit /b 1
)
echo Building native Veter window...
g++ -std=c++20 -O2 -Wall -Wextra -static -static-libgcc -static-libstdc++ Veter_Native_Engine.cpp -o veter-native.exe -lgdi32 -luser32 -lshell32
if errorlevel 1 (
  echo BUILD FAILED. Send a screenshot of the errors.
  pause
  exit /b 1
)
echo BUILD SUCCESSFUL.
echo Opening website.vtr in the native Veter window...
veter-native.exe website.vtr
if errorlevel 1 (
  echo Native runtime exited with an error.
  pause
)
