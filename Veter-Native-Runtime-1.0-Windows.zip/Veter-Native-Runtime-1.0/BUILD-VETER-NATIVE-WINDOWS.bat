@echo off
setlocal
cd /d "%~dp0"
echo ======================================
echo       VETER NATIVE UI RUNTIME
echo ======================================
where g++ >nul 2>nul
if errorlevel 1 (
  echo ERROR: g++ was not found.
  echo Open the MSYS2 UCRT64 terminal or add its bin folder to PATH.
  pause
  exit /b 1
)
g++ -std=c++20 -O2 -Wall -Wextra Veter_Native_Engine.cpp -o veter-native-preview.exe -lgdi32 -luser32 -lshell32
if errorlevel 1 (
  echo BUILD FAILED. Please send me the errors above.
  pause
  exit /b 1
)
echo BUILD SUCCESSFUL.
echo Launching your Veter website...
veter-native-preview.exe website.vtr
if errorlevel 1 (
  echo The preview closed with an error. Please send me this screen.
  pause
  exit /b 1
)
