// Veter Native UI Runtime - Windows prototype. User-authored source is .vtr only.
// This runtime draws native Windows controls; it does not generate HTML/CSS/JS.
#include <algorithm>
#include <cctype>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#endif

struct Item { std::string kind, text, url; };
struct Page {
    std::string name="Veter Website", title="Welcome to Veter", bg="white", fg="black", font="Arial";
    bool centered=false;
    std::vector<Item> items;
    std::map<std::string,std::string> alerts;
};
static std::string trim(std::string s){auto a=s.find_first_not_of(" \t\r\n");if(a==std::string::npos)return {};auto b=s.find_last_not_of(" \t\r\n");return s.substr(a,b-a+1);}
static std::string quoted(const std::string&s,size_t from=0){auto a=s.find('"',from);if(a==std::string::npos)return {};auto b=s.find('"',a+1);return b==std::string::npos?std::string():s.substr(a+1,b-a-1);}
static bool starts(const std::string&s,const std::string&p){return s.rfind(p,0)==0;}
static Page parse(const std::string&path){
 std::ifstream f(path);if(!f)throw std::runtime_error("Cannot open .vtr file: "+path);
 Page p;std::string line;
 while(std::getline(f,line)){line=trim(line);if(line.empty()||starts(line,"#"))continue;auto q=quoted(line);
  if(starts(line,"make a website called "))p.name=q;
  else if(starts(line,"set page title "))p.title=q;
  else if(starts(line,"set background color "))p.bg=trim(line.substr(21));
  else if(starts(line,"set text color "))p.fg=trim(line.substr(15));
  else if(starts(line,"set font "))p.font=q.empty()?trim(line.substr(9)):q;
  else if(line=="center content")p.centered=true;
  else if(starts(line,"show a title "))p.items.push_back({"title",q,{}});
  else if(starts(line,"show a subtitle "))p.items.push_back({"subtitle",q,{}});
  else if(starts(line,"show text "))p.items.push_back({"text",q,{}});
  else if(starts(line,"add a text box called "))p.items.push_back({"input",q,{}});
  else if(starts(line,"add a password box called "))p.items.push_back({"password",q,{}});
  else if(starts(line,"add a checkbox "))p.items.push_back({"checkbox",q,{}});
  else if(starts(line,"add a button "))p.items.push_back({"button",q,{}});
  else if(starts(line,"add a link ")){auto first=line.find('"');auto second=line.find('"',first+1);auto third=line.find('"',second+1);auto fourth=line.find('"',third+1);if(first!=std::string::npos&&second!=std::string::npos&&third!=std::string::npos&&fourth!=std::string::npos)p.items.push_back({"link",line.substr(first+1,second-first-1),line.substr(third+1,fourth-third-1)});}
  else if(starts(line,"when button ")){auto buttonName=q;auto at=line.find("show alert ");if(at!=std::string::npos)p.alerts[buttonName]=quoted(line,at);}
 }
 return p;
}
#ifndef _WIN32
int main(int argc,char**argv){if(argc!=2){std::cerr<<"Usage: veter-native-preview website.vtr\n";return 2;}try{auto p=parse(argv[1]);std::cout<<"Veter .vtr parser check passed\nWebsite: "<<p.name<<"\nTitle: "<<p.title<<"\nControls: "<<p.items.size()<<"\n";for(auto&i:p.items)std::cout<<i.kind<<": "<<i.text<<"\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
#else
struct NativeControl{HWND hwnd=nullptr;std::string kind,label,url;int itemIndex=0;};
static Page g_page;static std::vector<NativeControl> g_controls;static HFONT g_font=nullptr;static HBRUSH g_bgBrush=nullptr;static HWND g_window=nullptr;
static COLORREF colorOf(std::string c){std::transform(c.begin(),c.end(),c.begin(),[](unsigned char x){return (char)std::tolower(x);});if(c=="light blue")return RGB(219,234,254);if(c=="dark blue")return RGB(30,58,138);if(c=="blue")return RGB(59,130,246);if(c=="light green")return RGB(220,252,231);if(c=="green")return RGB(22,163,74);if(c=="red")return RGB(220,38,38);if(c=="yellow")return RGB(254,249,195);if(c=="gray"||c=="grey")return RGB(229,231,235);if(c=="white")return RGB(255,255,255);if(c=="black")return RGB(17,24,39);return RGB(255,255,255);}
static void draw(HDC dc,const std::string&s,int x,int y,int w,int h,int size,bool bold,bool center){RECT r{x,y,x+w,y+h};HFONT f=CreateFontA(size,0,0,0,bold?FW_BOLD:FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH|FF_DONTCARE,g_page.font.c_str());auto old=SelectObject(dc,f);SetBkMode(dc,TRANSPARENT);SetTextColor(dc,colorOf(g_page.fg));DrawTextA(dc,s.c_str(),-1,&r,(center?DT_CENTER:DT_LEFT)|DT_VCENTER|DT_SINGLELINE);SelectObject(dc,old);DeleteObject(f);}
static void layout(HWND hwnd){
 RECT cr{};GetClientRect(hwnd,&cr);int width=cr.right;int y=24;
 int labelX=g_page.centered?(width-520)/2:36;int editX=labelX+150;int buttonX=g_page.centered?(width-260)/2:36;
 for(size_t i=0;i<g_page.items.size();++i){const auto&it=g_page.items[i];
  if(it.kind=="title")y+=52;else if(it.kind=="subtitle")y+=44;else if(it.kind=="text")y+=42;
  else if(it.kind=="input"||it.kind=="password"){for(auto&c:g_controls)if(c.itemIndex==(int)i)MoveWindow(c.hwnd,editX,y+2,330,30,TRUE);y+=48;}
  else if(it.kind=="checkbox"){for(auto&c:g_controls)if(c.itemIndex==(int)i)MoveWindow(c.hwnd,labelX,y,420,30,TRUE);y+=44;}
  else if(it.kind=="button"||it.kind=="link"){for(auto&c:g_controls)if(c.itemIndex==(int)i)MoveWindow(c.hwnd,buttonX,y,260,40,TRUE);y+=54;}
 }
}
static void createControls(HWND hwnd){g_controls.clear();for(size_t i=0;i<g_page.items.size();++i){const auto&it=g_page.items[i];HWND h=nullptr;DWORD style=WS_CHILD|WS_VISIBLE;std::string kind=it.kind;
 if(kind=="input"||kind=="password"){h=CreateWindowExA(WS_EX_CLIENTEDGE,"EDIT","",style|ES_AUTOHSCROLL|(kind=="password"?ES_PASSWORD:0),0,0,10,10,hwnd,(HMENU)(INT_PTR)(1000+(int)i),GetModuleHandleA(nullptr),nullptr);}
 else if(kind=="checkbox"){h=CreateWindowExA(0,"BUTTON",it.text.c_str(),style|BS_AUTOCHECKBOX|WS_TABSTOP,0,0,10,10,hwnd,(HMENU)(INT_PTR)(1000+(int)i),GetModuleHandleA(nullptr),nullptr);}
 else if(kind=="button"||kind=="link"){h=CreateWindowExA(0,"BUTTON",it.text.c_str(),style|BS_PUSHBUTTON|WS_TABSTOP,0,0,10,10,hwnd,(HMENU)(INT_PTR)(1000+(int)i),GetModuleHandleA(nullptr),nullptr);}
 if(h){SendMessageA(h,WM_SETFONT,(WPARAM)g_font,TRUE);g_controls.push_back({h,kind,it.text,it.url,(int)i});}}
 layout(hwnd);}
static std::string inputValue(){for(auto&c:g_controls)if(c.kind=="input"){int n=GetWindowTextLengthA(c.hwnd);std::string s((size_t)n+1,'\0');GetWindowTextA(c.hwnd,s.data(),n+1);s.resize((size_t)n);return s;}return {};}
static LRESULT CALLBACK wndProc(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp){switch(msg){case WM_CREATE:createControls(hwnd);return 0;case WM_SIZE:layout(hwnd);return 0;case WM_ERASEBKGND:{RECT r{};GetClientRect(hwnd,&r);FillRect((HDC)wp,&r,g_bgBrush);return 1;}case WM_PAINT:{PAINTSTRUCT ps{};HDC dc=BeginPaint(hwnd,&ps);RECT cr{};GetClientRect(hwnd,&cr);FillRect(dc,&cr,g_bgBrush);int y=24;int x=g_page.centered?0:36;int w=g_page.centered?cr.right:cr.right-72;for(auto&it:g_page.items){if(it.kind=="title"){draw(dc,it.text,x,y,w,42,30,true,g_page.centered);y+=52;}else if(it.kind=="subtitle"){draw(dc,it.text,x,y,w,36,22,true,g_page.centered);y+=44;}else if(it.kind=="text"){draw(dc,it.text,x,y,w,34,18,false,g_page.centered);y+=42;}else if(it.kind=="input"||it.kind=="password"){draw(dc,it.text,g_page.centered?(cr.right-520)/2:36,y,145,32,16,false,false);y+=48;}else if(it.kind=="checkbox")y+=44;else if(it.kind=="button"||it.kind=="link")y+=54;}EndPaint(hwnd,&ps);return 0;}case WM_COMMAND:{if(HIWORD(wp)==BN_CLICKED){int id=LOWORD(wp);for(auto&c:g_controls){if((int)(1000+c.itemIndex)==id){if(c.kind=="button"){std::string message="Hello from Veter!";auto it=g_page.alerts.find(c.label);if(it!=g_page.alerts.end())message=it->second;auto pos=message.find("{name}");if(pos!=std::string::npos){std::string name=inputValue();if(name.empty())name="friend";message.replace(pos,6,name);}MessageBoxA(hwnd,message.c_str(),g_page.name.c_str(),MB_OK|MB_ICONINFORMATION);}else if(c.kind=="link"&&!c.url.empty())ShellExecuteA(hwnd,"open",c.url.c_str(),nullptr,nullptr,SW_SHOWNORMAL);break;}}}return 0;}case WM_DESTROY:if(g_font){DeleteObject(g_font);g_font=nullptr;}if(g_bgBrush){DeleteObject(g_bgBrush);g_bgBrush=nullptr;}PostQuitMessage(0);return 0;default:return DefWindowProcA(hwnd,msg,wp,lp);}}
static int showNative(Page p){g_page=std::move(p);HINSTANCE inst=GetModuleHandleA(nullptr);g_font=CreateFontA(18,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH|FF_DONTCARE,g_page.font.c_str());g_bgBrush=CreateSolidBrush(colorOf(g_page.bg));WNDCLASSEXA wc{};wc.cbSize=sizeof(wc);wc.lpfnWndProc=wndProc;wc.hInstance=inst;wc.hCursor=LoadCursorA(nullptr,IDC_ARROW);wc.hbrBackground=nullptr;wc.lpszClassName="VeterNativeRuntimeWindow";if(!RegisterClassExA(&wc)&&GetLastError()!=ERROR_CLASS_ALREADY_EXISTS){std::cerr<<"Window class registration failed: "<<GetLastError()<<"\n";return 1;}g_window=CreateWindowExA(0,wc.lpszClassName,g_page.title.c_str(),WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,920,720,nullptr,nullptr,inst,nullptr);if(!g_window){std::cerr<<"Window creation failed: "<<GetLastError()<<"\n";return 1;}ShowWindow(g_window,SW_SHOW);UpdateWindow(g_window);MSG m{};int result;while((result=(int)GetMessageA(&m,nullptr,0,0))>0){TranslateMessage(&m);DispatchMessageA(&m);}return result==-1?1:0;}
int main(int argc,char**argv){if(argc!=2){MessageBoxA(nullptr,"Usage: veter-native-preview website.vtr","Veter",MB_OK|MB_ICONINFORMATION);return 2;}try{return showNative(parse(argv[1]));}catch(const std::exception&e){MessageBoxA(nullptr,e.what(),"Veter preview error",MB_OK|MB_ICONERROR);return 1;}}
#endif
